This plugin is made by JavaBeast (discord: https://discord.com/invite/Wv3kk3BSRM)
To use this plugin it is important to put the AdminPanel.jar AND the AdminPanel folder into the plugin folder

This Plugin creates a WebServer (HttpServer) on port 1997 (you can always change the port in the config.yml file)
To access the page you have to be playing on the server, have a registered account in the config.yml file
(example given as usr.Javabeast)

then you have to access the website like the following http://<ip>:<port>/?usr=<usr>&pw=<pw>.

if everything works correctly you should see the default webpanel.
you can add/remove/edit buttons in the root.yml file.
NEVER change the root.html file. 

If a config is not working (or you changed something in the root.html file) you can always find every file on github:
https://github.com/JavaBeast24/AdminPanel

If you need help, have a question, get infos about updates visit my discord Server:
discord: https://discord.com/invite/Wv3kk3BSRM